module.exports = {

    LOADER_START_EVENT: require('./LoaderStartEvent'),
    LOADER_COMPLETE_EVENT: require('./LoaderCompleteEvent')

};
